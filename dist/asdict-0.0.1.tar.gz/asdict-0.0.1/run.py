from asdict import read_as_dict
if __name__ == "__main__":
    filename = 'example-dicts/example2.dict'
    test = read_as_dict(filename)
    print(test)
