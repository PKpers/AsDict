class BlockError(Exception):
    pass
#
class StructureError(Exception):
    pass

